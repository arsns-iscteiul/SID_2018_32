LOAD DATA INFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/mytable.csv' 
	IGNORE INTO TABLE ola.logmedicaotemp 
	FIELDS TERMINATED BY ',' 
	ENCLOSED BY '"' 
	LINES TERMINATED BY '\n';