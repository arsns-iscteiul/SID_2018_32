DELIMITER $$

DROP PROCEDURE IF EXISTS fileExp $$

-- Create the stored procedure to perform the migration
CREATE PROCEDURE fileExp()

begin
	if LOAD_FILE('C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/mytable.csv') IS NULL then
  select * FROM sys.logmedicaotemp INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/mytable.csv' 
  FIELDS TERMINATED BY ',' 
  ENCLOSED BY '"' 
  LINES TERMINATED BY '\n';
  DELETE  from sys.logmedicaotemp;
  end if;
  end $$
  
  
-- Execute the stored procedure
CALL fileExp() $$

-- Don't forget to drop the stored procedure when you're done!
DROP PROCEDURE IF EXISTS fileExp $$
 
DELIMITER ;